document.documentElement.lang ="pt-BR";

document.getElementById("formContato").addEventListener("submit", function(event){

    let nome = document.getElementById("nome").value.trim();
    let email = document.getElementById("email").value.trim();
    let assunto = document.getElementById("assunto").value.trim();
    let descricao = document.getElementById("descricao").value.trim();

    if(nome === "" || email === "" || assunto === "" || descricao === ""){
        alert("Por favor, preencha todos os campos obrigatórios.");
        event.preventDefault(); // impede envio do formulário
    } else {
        alert("Formulário enviado com sucesso!");
    }

});